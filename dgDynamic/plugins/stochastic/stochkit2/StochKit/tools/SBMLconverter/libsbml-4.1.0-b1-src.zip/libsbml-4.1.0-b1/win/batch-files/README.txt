The files in this directory make assumptions about the locations
of third party software on a windows system.  Care should be
taken when using them.