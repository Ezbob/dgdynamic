#include "staticCalibrator.h"

int main(int argc, char* argv[])
{
  staticCalibrator calibrator(argc, argv);

  return 0;
}
